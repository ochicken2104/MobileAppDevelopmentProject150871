package com.example.ExpenseLogger

data class Expenses(
    val id: Int?,
    var username: String?,
    var activityName: String?,
    var cost: Double?,
    var expenseType: String?,
    var description: String?
)
