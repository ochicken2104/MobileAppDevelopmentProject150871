package com.example.ExpenseLogger

data class Users(
    var profileName : String?,
    var username: String?,
    var password: String?
)
